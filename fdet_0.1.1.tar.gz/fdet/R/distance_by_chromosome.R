#' @title distance_by_chromosome
#' @description Cut a chromosome by 0.5Mb window and evaluate expression change.Bin size=40kb.
#' @details Input DGE is a data.frame x , which is the annotated result of DGE like DESeq2 or limma. Input chromosome is a string as chromosome number.
#' @param DGE -> a data.frame. Must containing these columns: log2FoldChange chr start end gene_name
#' @param chromosome -> a string without "chr"
#' @return A dataframe with each window and evaluation of whole window expression change.
#' @importFrom stats dbinom wilcox.test
#' @export 

distance_by_chromosome<-function(DGE,chromosome){
  expection_DGE=length(which(abs(DGE$log2FoldChange)>=2))/length(DGE$log2FoldChange)
  mean_all=mean(DGE$log2FoldChange)
  sd_all=sd(DGE$log2FoldChange)
  chr_DGE<-subset(DGE,chr==chromosome)
  window_num<-max(chr_DGE$start) %/% 40000
  matrix<-matrix(ncol=9,nrow=window_num+1)
  for (i in 0:window_num){
    DGE_1Mwindow = subset(chr_DGE,start>i*40000 & start <(i*40000 +500000))
    windowNo = paste("chr",chromosome,"_",i+1,sep="")
    window_5pos = i*40000
    window_3pos = (i*40000 + 500000)
    gene_number = nrow(DGE_1Mwindow)
    E_w = nrow(DGE_1Mwindow)*expection_DGE
    O_w = length(which(abs(DGE_1Mwindow$log2FoldChange)>=2))
    mean_log2FC = mean(DGE_1Mwindow$log2FoldChange)
    P.wilcox = ifelse(nrow(DGE_1Mwindow)>5,wilcox.test(DGE_1Mwindow$log2FoldChange,mu=mean_all,exact=T)[[3]],"-")
    regulation = checkwindowlog2foldchange(DGE_1Mwindow$log2FoldChange)
    stat = c(windowNo,window_5pos,window_3pos,gene_number,E_w,O_w,mean_log2FC,P.wilcox,regulation)
    matrix[i+1,]<-stat
  }
  colnames(matrix)<-c("windowNo","window_5pos","window_3pos","gene_number","E_w","O_w","mean_log2FC","P.wilcox","regulation")
  matrix<-as.data.frame(matrix)
  matrix<-subset(matrix,gene_number>5)
  matrix$window_5pos<-as.numeric(matrix$window_5pos)
  matrix$window_3pos<-as.numeric(matrix$window_3pos)
  matrix$gene_number<-as.numeric(matrix$gene_number)
  matrix$E_w<-as.numeric(matrix$E_w)
  matrix$O_w<-as.numeric(matrix$O_w)
  matrix$mean_log2FC<-as.numeric(matrix$mean_log2FC)
  matrix$Z_score<-(matrix$mean_log2FC-mean_all)/(sd_all/sqrt(nrow(matrix)))
  matrix$delta_g<-matrix$O_w-matrix$E_w
  matrix$P.wilcox<-as.numeric(matrix$P.wilcox)
  matrix$P.binom<-dbinom(x=matrix$O_w,size=matrix$gene_number,prob=expection_DGE,log=F)
  return(matrix)
}
