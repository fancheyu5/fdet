#' @title checkwindowlog2foldchange
#' @description Check the direction of regulation of a window on the chromosome.
#' @details Input takes a numeric vector of log2FC change. Cut-off value is ±2.
#' @param log2FC--a numeric vector
#' @return A vector representing the direction of regulation of each window.
#' @export 

checkwindowlog2foldchange<-function(log2FC){
  if (min(log2FC)>(-2) & max(log2FC)<2) {
    return("neutral")
  } else if (min(log2FC)>(-2) & max(log2FC)>2){
    return("UPregulated")
  } else if (min(log2FC)<(-2) & max(log2FC)<2){
    return("DOWNregulated")
  } else if (min(log2FC)<(-2) & max(log2FC)>2) {
    return("2-side_regulated")
  }
}
